package com.vebration35.myrecipeapp.model;

import java.util.List;
import java.util.Map;

public class UserModel {// Wallet
    public String uid;
    public String userProvider;
    public String profileUrl;
    public String email;
    public String displayName;

}